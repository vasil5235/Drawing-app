
let canvas = document.querySelector('canvas');
let ColorPicker = document.getElementById('color');
let size = document.getElementById('range');
let ctx = canvas.getContext('2d');
let IsMouseDown = false;
let IsMouseOnCanvas = false;
ctx.fillStyle = ColorPicker.value;
ctx.fillStyle = '#fff';ctx.fillRect(0, 0, canvas.width, canvas.height);
function resizeCanvas() {
    // Get actual CSS size
    const displayWidth = canvas.clientWidth;
    const displayHeight = canvas.clientHeight;

    // Handle high-DPI screens
    const scale = window.devicePixelRatio || 1;

    canvas.width = displayWidth * scale;
    canvas.height = displayHeight * scale;

    ctx.setTransform(1, 0, 0, 1, 0, 0); // Reset any existing transform
    ctx.scale(scale, scale);

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#fff';ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = ColorPicker.value;
}



window.addEventListener('resize', resizeCanvas);
resizeCanvas(); // Initial setup
document.addEventListener('mousedown', function (event) {
    IsMouseDown = true;

})

document.addEventListener('mouseup', function (event) {
    IsMouseDown = false;

})

document.addEventListener('mousemove', function (event) {
    if(IsMouseDown&& IsMouseOnCanvas)
    {


        ctx.beginPath();
        ctx.arc(event.offsetX,event.offsetY,size.value,0,Math.PI*2,false);
        ctx.fill();

    }

})

canvas.addEventListener('mouseover', function (event) {
    IsMouseOnCanvas = true;

})

canvas.addEventListener('mouseout', function (event) {
    IsMouseOnCanvas = false;
})
canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
}, { passive: false });
document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && (e.key === '+' || e.key === '-' || e.key === '=')) {
        e.preventDefault();
    }
});
document.getElementById('Save').addEventListener('click', (e) => {
    console.log('Save');
    let save = document.createElement('a');
    save.href = canvas.toDataURL('image/png');
    save.download = 'save.png';
    save.click();
})
document.getElementById('clear').addEventListener('click', (e) => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#fff';ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = ColorPicker.value;
})
document.getElementById('erase').addEventListener('click', (e) => {
    ctx.fillStyle = "#ffffff";
})
ColorPicker.addEventListener('change', function (e) {
    ctx.fillStyle = ColorPicker.value;
})
document.getElementById('pen').addEventListener('click', function (e) {
    ctx.fillStyle = ColorPicker.value;
})
document.getElementById('secret').addEventListener('click', () => {
    window.open('https://youtu.be/dQw4w9WgXcQ?si=n2c8KK8YNfLmyY9s', '_blank');
});